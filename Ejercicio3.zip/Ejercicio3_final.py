# Ejercicio 3 - Entrada para ejecutar el proyecto organizado como en la clase.
# Los cálculos están en sustentabilidad/services.py.
# Las pruebas están en sustentabilidad/tests.py.
# La vista y sus rutas están en sustentabilidad/views.py y urls.py.
# La plantilla está en sustentabilidad/templates/sustentabilidad/panel.html.
import subprocess
import sys
from pathlib import Path


if __name__ == "__main__":
    # Usa el entorno virtual del proyecto, donde está instalado Django.
    carpeta_proyecto = Path(__file__).resolve().parent
    python_entorno = carpeta_proyecto / ".venv" / "Scripts" / "python.exe"

    # Al ejecutar con el botón de VS Code, corre las pruebas de la aplicación.
    # También admite comandos, por ejemplo: python Ejercicio3_final.py runserver
    argumentos = sys.argv[1:] or ["test", "sustentabilidad"]
    resultado = subprocess.run(
        [str(python_entorno), str(carpeta_proyecto / "manage.py"), *argumentos],
        cwd=carpeta_proyecto,
    )
    sys.exit(resultado.returncode)
