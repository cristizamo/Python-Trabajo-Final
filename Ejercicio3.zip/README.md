# Ejercicio 3 - Auditoría con tests unitarios e integración web

EcoTech Solutions. Proyecto Django organizado siguiendo la clase del profesor.

## Archivos

- manage.py y config/ configuran y ejecutan el proyecto.
- sustentabilidad/services.py contiene calcular_emisiones_carbono y obtener_metricas_consumo.
- sustentabilidad/tests.py contiene TestCalculoEmisiones(unittest.TestCase) y las pruebas de integración.
- sustentabilidad/views.py contiene vista_panel_sustentabilidad.
- sustentabilidad/urls.py conecta la ruta del panel.
- sustentabilidad/templates/sustentabilidad/panel.html muestra las métricas.
- Ejercicio3_final.py permite ejecutar las pruebas o iniciar el servidor usando el entorno virtual.

## Preparación en otra computadora

Extraer todo el ZIP en una carpeta y abrir esa carpeta en Visual Studio Code.
En la terminal de PowerShell, desde la carpeta que contiene manage.py, ejecutar:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## Pruebas y panel

```powershell
.\.venv\Scripts\python.exe manage.py test sustentabilidad
.\.venv\Scripts\python.exe manage.py runserver
```

Abrir http://127.0.0.1:8000/sustentabilidad/panel/ en el navegador.
Para detener el servidor, presionar Ctrl+C.

También se puede ejecutar python Ejercicio3_final.py para correr las pruebas,
o python Ejercicio3_final.py runserver para iniciar el servidor, una vez preparado
el entorno virtual.

## Resultado con los datos de ejemplo

Emisiones globales de 1060 kg de CO₂. Planta Norte tiene el mayor consumo
acumulado, con 1300 kWh. Las emisiones por planta son Norte 520 kg, Sur 400 kg
y Este 140 kg. Se conservan los datos de ejemplo de la solución de la estudiante.

Punto A: cuatro pruebas de cálculo nominal, factor personalizado, consumo cero
y excepción ValueError ante consumo negativo.
Punto B: procesamiento del historial, contexto, rutas y renderizado de la plantilla.
El archivo tests.py agrega cuatro verificaciones de agrupación e integración web.
