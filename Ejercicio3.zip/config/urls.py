# Conecta las rutas de la aplicación con las del proyecto.
from django.urls import include, path

urlpatterns = [
    path("sustentabilidad/", include("sustentabilidad.urls")),
]
