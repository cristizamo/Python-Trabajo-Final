# Ejercicio 3 - Auditoría con tests unitarios e integración web.
# Este módulo reúne los cálculos utilizados por las pruebas y la vista.


# Punto A - Algoritmo de cálculo de emisiones.
# Recibe consumo en kWh y un factor en kg de CO₂ por kWh.
def calcular_emisiones_carbono(consumo_kwh, factor_emision=0.4):
    # Rechaza consumos negativos antes de calcular las emisiones.
    if consumo_kwh < 0:
        raise ValueError("El consumo en kWh no puede ser negativo.")
    return consumo_kwh * factor_emision


# Punto B - Procesamiento de Métricas (obtener_metricas_consumo).
# Cada registro del historial contiene planta y consumo_kwh.
def obtener_metricas_consumo(registros):
    total_global_emisiones = 0.0
    consumo_por_planta = {}
    emisiones_por_planta = {}

    for registro in registros:
        planta = registro["planta"]
        consumo_kwh = registro["consumo_kwh"]

        # Reutiliza la función auditada y acumula las emisiones globales.
        emisiones = calcular_emisiones_carbono(consumo_kwh)
        total_global_emisiones += emisiones

        # Agrupa todas las lecturas de cada planta para obtener sus totales.
        consumo_por_planta[planta] = consumo_por_planta.get(planta, 0) + consumo_kwh
        emisiones_por_planta[planta] = emisiones_por_planta.get(planta, 0) + emisiones

    # Busca el mayor consumo acumulado. Si hay empate, elige la primera
    # planta registrada con ese consumo. Si no hay datos, devuelve None.
    planta_mayor_consumo = max(
        consumo_por_planta,
        key=consumo_por_planta.get,
        default=None,
    )

    # La vista utiliza estas métricas para construir el contexto del panel.
    return {
        "total_global_emisiones": total_global_emisiones,
        "planta_mayor_consumo": planta_mayor_consumo,
        "mayor_consumo_kwh": consumo_por_planta.get(planta_mayor_consumo, 0),
        "emisiones_por_planta": emisiones_por_planta,
    }
