# Ejercicio 3, Punto A - Auditoría del algoritmo con unittest.
import unittest
from unittest.mock import patch

from django.test import SimpleTestCase
from django.urls import reverse

from .services import calcular_emisiones_carbono, obtener_metricas_consumo


class TestCalculoEmisiones(unittest.TestCase):
    def test_consumo_positivo_con_factor_por_defecto(self):
        # Comprueba 12.3 × 0.4 con tolerancia de punto flotante.
        self.assertAlmostEqual(calcular_emisiones_carbono(12.3), 4.92)

    def test_factor_personalizado(self):
        # Verifica que se utilice el factor recibido como argumento.
        self.assertAlmostEqual(calcular_emisiones_carbono(100, 0.25), 25.0)

    def test_consumo_cero(self):
        # Un consumo de cero produce cero emisiones.
        self.assertEqual(calcular_emisiones_carbono(0), 0.0)

    def test_consumo_negativo(self):
        # Pasa la función y su argumento a assertRaises, como en el video.
        self.assertRaises(ValueError, calcular_emisiones_carbono, -50)


# Verifica la agrupación del historial antes de mostrarlo en la web.
class TestMetricasConsumo(unittest.TestCase):
    def test_acumula_registros_de_la_misma_planta(self):
        registros = [
            {"planta": "Norte", "consumo_kwh": 800},
            {"planta": "Sur", "consumo_kwh": 1000},
            {"planta": "Norte", "consumo_kwh": 500},
        ]
        metricas = obtener_metricas_consumo(registros)
        self.assertAlmostEqual(metricas["total_global_emisiones"], 920.0)
        self.assertEqual(metricas["planta_mayor_consumo"], "Norte")
        self.assertEqual(metricas["mayor_consumo_kwh"], 1300)
        self.assertEqual(metricas["emisiones_por_planta"], {"Norte": 520.0, "Sur": 400.0})

    def test_historial_vacio(self):
        self.assertEqual(obtener_metricas_consumo([]), {
            "total_global_emisiones": 0.0,
            "planta_mayor_consumo": None,
            "mayor_consumo_kwh": 0,
            "emisiones_por_planta": {},
        })


# Punto B - Comprueba que la URL, la vista y la plantilla estén conectadas.
class TestPanelSustentabilidad(SimpleTestCase):
    def test_muestra_metricas_y_desglose(self):
        respuesta = self.client.get(reverse("panel_sustentabilidad"))
        self.assertEqual(respuesta.status_code, 200)
        self.assertTemplateUsed(respuesta, "sustentabilidad/panel.html")
        self.assertEqual(respuesta.context["total_emisiones"], 1060.0)
        self.assertEqual(respuesta.context["planta_mayor_consumo"], "Planta Norte")
        self.assertEqual(respuesta.context["detalle_emisiones"], {
            "Planta Norte": 520.0,
            "Planta Sur": 400.0,
            "Planta Este": 140.0,
        })
        self.assertContains(respuesta, "1060,00")
        self.assertContains(respuesta, "520,00")

    def test_muestra_mensaje_si_no_hay_registros(self):
        with patch("sustentabilidad.views.REGISTROS_CONSUMO_DEMO", []):
            respuesta = self.client.get(reverse("panel_sustentabilidad"))
        self.assertContains(respuesta, "No hay registros de consumo.")
