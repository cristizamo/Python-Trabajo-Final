# Ejercicio 3, Punto B - Procesamiento de Métricas y Renderizado Web.
from django.shortcuts import render

from .services import obtener_metricas_consumo


# Historial de ejemplo. Una planta puede aparecer en varios registros.
REGISTROS_CONSUMO_DEMO = [
    {"planta": "Planta Norte", "consumo_kwh": 800},
    {"planta": "Planta Sur", "consumo_kwh": 1000},
    {"planta": "Planta Norte", "consumo_kwh": 500},
    {"planta": "Planta Este", "consumo_kwh": 350},
]


def vista_panel_sustentabilidad(request):
    # La función de servicios procesa el historial y devuelve las métricas.
    metricas = obtener_metricas_consumo(REGISTROS_CONSUMO_DEMO)

    # Construye el diccionario de contexto, como se explica en el video.
    contexto = {
        "total_emisiones": metricas["total_global_emisiones"],
        "planta_mayor_consumo": metricas["planta_mayor_consumo"],
        "mayor_consumo_kwh": metricas["mayor_consumo_kwh"],
        "detalle_emisiones": metricas["emisiones_por_planta"],
    }

    # Combina la plantilla con los datos y devuelve una respuesta HTTP.
    return render(request, "sustentabilidad/panel.html", contexto)
